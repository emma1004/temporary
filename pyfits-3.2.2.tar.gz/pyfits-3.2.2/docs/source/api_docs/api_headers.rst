.. currentmodule:: pyfits

*******
Headers
*******

:class:`Header`
===============

.. autoclass:: Header
   :members:
   :inherited-members:
   :undoc-members:
   :show-inheritance:
